CREATE TABLE IF NOT EXISTS `service_requests` (
  `id` int AUTO_INCREMENT NOT NULL,
  `name` varchar(160) NOT NULL,
  `email` varchar(320) NOT NULL,
  `phone` varchar(40),
  `device` varchar(80) NOT NULL,
  `issue` text NOT NULL,
  `status` enum('pending','in_progress','completed','cancelled') NOT NULL DEFAULT 'pending',
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `service_requests_id` PRIMARY KEY(`id`),
  INDEX `service_requests_created_at_idx` (`createdAt`),
  INDEX `service_requests_status_idx` (`status`)
);
