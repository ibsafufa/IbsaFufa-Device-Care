# Device Care Services

## Homepage communicates reliable device support
- [x] The homepage presents a clear repair and support value proposition for computers, mobile devices, and laptops.
- [x] The page uses the user-provided portrait prominently to personalize the business and build trust.
- [x] The page includes a strong call to action for requesting help or booking a repair.

## Device services are easy to understand
- [x] Dedicated service sections cover computer support, mobile support, and laptop support.
- [x] Trust-building content explains the benefits and sets clear expectations for customers.

## Process and about content build confidence
- [x] The page includes the approved three-step process: Listen first, Make a plan, and Move with care.
- [x] The page includes an about section introducing the technician/service provider.

## Responsive inquiry experience
- [x] A clear service inquiry form is available with name, email, device type, and issue fields.
- [x] Strong CTA links scroll to the inquiry form.
- [x] The layout adapts for desktop, tablet, and mobile screens.
