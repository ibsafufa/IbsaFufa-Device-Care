import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { createServiceRequest, deleteServiceRequest, listServiceRequests, updateServiceRequestStatus } from "./db";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  serviceRequests: router({
    create: publicProcedure.input(z.object({
      name: z.string().trim().min(2).max(160),
      email: z.string().trim().email().max(320),
      phone: z.string().trim().max(40).optional().or(z.literal("")),
      device: z.string().trim().min(1).max(80),
      issue: z.string().trim().min(5).max(5000),
    })).mutation(async ({ input }) => {
      await createServiceRequest({
        name: input.name,
        email: input.email,
        phone: input.phone || null,
        device: input.device,
        issue: input.issue,
        status: "pending",
      });
      return { success: true };
    }),
    list: adminProcedure.query(() => listServiceRequests()),
    updateStatus: adminProcedure.input(z.object({
      id: z.number().int().positive(),
      status: z.enum(["pending", "in_progress", "completed", "cancelled"]),
    })).mutation(({ input }) => updateServiceRequestStatus(input.id, input.status)),
    delete: adminProcedure.input(z.object({ id: z.number().int().positive() }))
      .mutation(({ input }) => deleteServiceRequest(input.id)),
  }),
});

export type AppRouter = typeof appRouter;
