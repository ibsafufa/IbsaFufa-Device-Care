import { useMemo, useState } from "react";
import { Link } from "wouter";
import { ArrowLeft, Search, RefreshCw, LogOut, Inbox, Clock3, CheckCircle2, Wrench, Trash2 } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { startLogin } from "@/const";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";

type Status = "pending" | "in_progress" | "completed" | "cancelled";

export default function Admin() {
  const { user, loading, logout } = useAuth();
  const [search, setSearch] = useState("");
  const requests = trpc.serviceRequests.list.useQuery(undefined, { enabled: Boolean(user?.role === "admin"), retry: false });
  const utils = trpc.useUtils();
  const update = trpc.serviceRequests.updateStatus.useMutation({ onSuccess: () => { utils.serviceRequests.list.invalidate(); toast.success("Request status updated"); }, onError: e => toast.error(e.message) });
  const remove = trpc.serviceRequests.delete.useMutation({ onSuccess: () => { utils.serviceRequests.list.invalidate(); toast.success("Request deleted"); }, onError: e => toast.error(e.message) });
  const rows = useMemo(() => (requests.data || []).filter(r => [r.name, r.email, r.phone || "", r.device, r.issue].join(" ").toLowerCase().includes(search.toLowerCase())), [requests.data, search]);
  const counts = { total: requests.data?.length || 0, pending: requests.data?.filter(r => r.status === "pending").length || 0, active: requests.data?.filter(r => r.status === "in_progress").length || 0, completed: requests.data?.filter(r => r.status === "completed").length || 0 };

  if (loading) return <div className="admin-loading">Loading administrator access…</div>;
  if (!user) return <main className="admin-gate"><div className="admin-gate-card"><Wrench size={34}/><h1>Device Care Admin</h1><p>Sign in with the administrator account to view customer requests.</p><Button onClick={() => startLogin()}>Sign in securely</Button><Link href="/">Back to website</Link></div></main>;
  if (user.role !== "admin") return <main className="admin-gate"><div className="admin-gate-card"><h1>Administrator access required</h1><p>This account does not have the admin role. Sign in with the project owner account or have the database administrator grant the admin role.</p><Button variant="outline" onClick={() => logout()}>Sign out</Button><Link href="/">Back to website</Link></div></main>;

  return <main className="admin-page"><header className="admin-topbar"><div><Link href="/" className="admin-back"><ArrowLeft size={16}/> View website</Link><h1>Device Care <span>Admin</span></h1><p>Customer service requests</p></div><div className="admin-top-actions"><Button variant="outline" onClick={() => requests.refetch()}><RefreshCw size={16}/> Refresh</Button><Button variant="ghost" onClick={() => logout()}><LogOut size={16}/> Sign out</Button></div></header>
    <section className="admin-stats"><article><Inbox/><span>Total requests</span><strong>{counts.total}</strong></article><article><Clock3/><span>Pending</span><strong>{counts.pending}</strong></article><article><Wrench/><span>In progress</span><strong>{counts.active}</strong></article><article><CheckCircle2/><span>Completed</span><strong>{counts.completed}</strong></article></section>
    <section className="admin-list"><div className="admin-list-heading"><div><h2>All requests</h2><p>Customer submissions are stored in the connected database.</p></div><div className="admin-search"><Search size={17}/><Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search name, email, device…"/></div></div>
      {requests.isLoading ? <p className="admin-empty">Loading requests…</p> : requests.error ? <div className="admin-error">{requests.error.message}. Check that the database migration has been applied.</div> : rows.length === 0 ? <div className="admin-empty">{search ? "No matching requests." : "No customer requests yet. New submissions will appear here."}</div> : <div className="request-table-wrap"><table className="request-table"><thead><tr><th>Customer</th><th>Device & issue</th><th>Date</th><th>Status</th><th>Action</th></tr></thead><tbody>{rows.map(r => <tr key={r.id}><td><strong>{r.name}</strong><a href={`mailto:${r.email}`}>{r.email}</a>{r.phone && <a href={`tel:${r.phone}`}>{r.phone}</a>}</td><td><strong>{r.device}</strong><p>{r.issue}</p></td><td>{new Date(r.createdAt).toLocaleString()}</td><td><Select value={r.status} onValueChange={(v) => update.mutate({ id: r.id, status: v as Status })}><SelectTrigger className="status-select"><SelectValue/></SelectTrigger><SelectContent><SelectItem value="pending">Pending</SelectItem><SelectItem value="in_progress">In progress</SelectItem><SelectItem value="completed">Completed</SelectItem><SelectItem value="cancelled">Cancelled</SelectItem></SelectContent></Select></td><td><Button size="icon" variant="ghost" aria-label="Delete request" onClick={() => { if (window.confirm("Delete this customer request permanently?")) remove.mutate({ id: r.id }); }}><Trash2 size={17}/></Button></td></tr>)}</tbody></table></div>}
    </section><footer className="admin-footer">Signed in as {user.name || user.email || "Administrator"}</footer></main>;
}
