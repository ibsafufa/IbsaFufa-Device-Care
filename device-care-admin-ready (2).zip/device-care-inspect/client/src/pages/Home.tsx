import {
  ArrowUpRight,
  Check,
  ChevronDown,
  Clock3,
  Laptop,
  Mail,
  Menu,
  Music2,
  MessageCircle,
  MonitorCog,
  Send,
  ShieldCheck,
  Smartphone,
  Wrench,
  X,
} from "lucide-react";
import { FormEvent, useState } from "react";
import { trpc } from "@/lib/trpc";

const portrait = "/manus-storage/ibsa_5ffa70fa.jpg";

const services = [
  {
    number: "01",
    icon: MonitorCog,
    title: "Computer support",
    description:
      "Setup, troubleshooting, cleanup, and everyday support that keeps your computer dependable.",
    tags: ["Setup & tune-ups", "Troubleshooting"],
  },
  {
    number: "02",
    icon: Smartphone,
    title: "Mobile help",
    description:
      "Practical help with phone setup, data transfer, apps, connectivity, and getting your device back on track.",
    tags: ["Device setup", "Data & apps"],
  },
  {
    number: "03",
    icon: Laptop,
    title: "Laptop care",
    description:
      "Careful laptop diagnosis, performance improvements, software fixes, and guidance without the jargon.",
    tags: ["Performance", "Software fixes"],
  },
];

const process = [
  {
    number: "01",
    title: "Listen first",
    copy: "We start with a simple conversation about your device, your goals, and what is currently getting in the way.",
  },
  {
    number: "02",
    title: "Make a plan",
    copy: "You get a focused path forward with practical actions, clear responsibilities, and realistic timing.",
  },
  {
    number: "03",
    title: "Move with care",
    copy: "I stay close to the work, communicate clearly, and help turn the plan into steady progress.",
  },
];

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const createRequest = trpc.serviceRequests.create.useMutation();
  const [submitError, setSubmitError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const closeMenu = () => setMenuOpen(false);

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSubmitError("");
    setSubmitting(true);
    const form = event.currentTarget;
    const data = new FormData(form);
    try {
      await createRequest.mutateAsync({
        name: String(data.get("name") || ""),
        email: String(data.get("email") || ""),
        phone: String(data.get("phone") || ""),
        device: String(data.get("device") || ""),
        issue: String(data.get("issue") || ""),
      });
      setSubmitted(true);
      form.reset();
    } catch (error) {
      console.error("Service request submission failed", error);
      setSubmitError("Sorry, your request could not be saved. Please try again or contact us by email.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="site-shell">
      <header className="site-header">
        <div className="header-inner">
          <a className="brand" href="#top" onClick={closeMenu}>
            <span className="brand-mark" aria-hidden="true">
              <Wrench size={18} strokeWidth={2.4} />
            </span>
            <span>
              <strong>Ibsa-Fufa Device Care</strong>
              <small>Computer · Mobile · Laptop</small>
            </span>
          </a>
          <button
            className="menu-toggle"
            type="button"
            aria-label={menuOpen ? "Close menu" : "Open menu"}
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen((open) => !open)}
          >
            {menuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
          <nav className={menuOpen ? "main-nav is-open" : "main-nav"}>
            <a href="#services" onClick={closeMenu}>Services</a>
            <a href="#process" onClick={closeMenu}>How it works</a>
            <a href="#about" onClick={closeMenu}>About</a>
            <a className="nav-cta" href="#contact" onClick={closeMenu}>
              Request help <ArrowUpRight size={16} />
            </a>
          </nav>
        </div>
      </header>

      <main id="top">
        <section className="hero-section">
          <div className="hero-copy">
            <p className="eyebrow"><span /> Calm, capable technology support</p>
            <h1>Less noise.<br /><em>More progress.</em></h1>
            <p className="hero-lede">
              Straightforward, reliable support for computers, mobile devices, and laptops—with clear communication, honest updates, and practical solutions.
            </p>
            <div className="hero-actions">
              <a className="button button-primary" href="#contact">
                Request help <ArrowUpRight size={17} />
              </a>
              <a className="text-link" href="#services">Explore services <ChevronDown size={16} /></a>
            </div>
            <a className="hero-help-card" href="#contact">
              <span className="hero-help-icon"><MessageCircle size={18} /></span>
              <span><strong>Request help</strong><small>Tell me what needs attention</small></span>
              <ArrowUpRight size={18} />
            </a>
            <div className="hero-proof">
              <span><Check size={15} /> Plain-language advice</span>
              <span><Check size={15} /> Careful, personal service</span>
            </div>
          </div>
          <div className="hero-portrait-wrap">
            <div className="portrait-accent portrait-accent-one" />
            <div className="portrait-accent portrait-accent-two" />
            <div className="portrait-card">
              <img src={portrait} alt="Your Device Care technician" />
              <div className="portrait-caption">
                <span className="status-dot" />
                <span><strong>Here to help.</strong><br />One clear step at a time.</span>
              </div>
            </div>
            <div className="portrait-note"><ShieldCheck size={17} /><span>Trusted support<br /><strong>without the jargon</strong></span></div>
          </div>
        </section>

        <section className="ticker" aria-label="Services offered">
          <div>Computer support</div><span>✦</span><div>Mobile help</div><span>✦</span><div>Laptop care</div><span>✦</span><div>Clear answers</div><span>✦</span><div>Steady progress</div>
        </section>

        <section className="services-section section" id="services">
          <div className="section-intro split-intro">
            <div>
              <p className="eyebrow"><span /> What I can help with</p>
              <h2>Small fixes.<br /><em>Big relief.</em></h2>
            </div>
            <p>When your technology gets in the way, you do not need more complexity. You need a clear answer, a practical next step, and someone who takes the time to get it right.</p>
          </div>
          <div className="service-list">
            {services.map(({ number, icon: Icon, title, description, tags }) => (
              <article className="service-row" key={title}>
                <div className="service-number">{number}</div>
                <div className="service-icon"><Icon size={24} strokeWidth={1.8} /></div>
                <div className="service-content">
                  <h3>{title}</h3>
                  <p>{description}</p>
                  <div className="service-tags">{tags.map((tag) => <span key={tag}>{tag}</span>)}</div>
                </div>
                <ArrowUpRight className="service-arrow" size={23} />
              </article>
            ))}
          </div>
        </section>

        <section className="process-section section" id="process">
          <div className="process-heading">
            <p className="eyebrow eyebrow-light"><span /> A better way to get unstuck</p>
            <h2>Support that keeps<br /><em>moving.</em></h2>
          </div>
          <div className="process-list">
            {process.map(({ number, title, copy }) => (
              <article className="process-card" key={title}>
                <span className="process-number">{number}</span>
                <div className="process-line" />
                <h3>{title}</h3>
                <p>{copy}</p>
              </article>
            ))}
          </div>
        </section>

        <section className="about-section section" id="about">
          <div className="about-photo"><img src={portrait} alt="Device Care technician smiling" /></div>
          <div className="about-copy">
            <p className="eyebrow"><span /> A real person behind the service</p>
            <h2>Good technology<br /><em>should feel simple.</em></h2>
            <p className="about-lede">I help people feel confident with the devices they rely on every day. That means listening carefully, explaining things clearly, and doing the work with the same care I would want for my own technology.</p>
            <div className="about-points">
              <div><ShieldCheck size={19} /><span><strong>Honest guidance</strong> — recommendations that fit your needs, not a sales script.</span></div>
              <div><Clock3 size={19} /><span><strong>Respect for your time</strong> — realistic expectations and updates along the way.</span></div>
            </div>
            <a className="text-link" href="#contact">Start a conversation <ArrowUpRight size={16} /></a>
          </div>
        </section>

        <section className="contact-section section" id="contact">
          <div className="contact-intro">
            <p className="eyebrow"><span /> Let’s get you moving</p>
            <h2>Tell me what is<br /><em>getting in the way.</em></h2>
            <p>Share a few details and I’ll get back to you with a clear next step. No jargon. No pressure.</p>
            <div className="contact-details">
              <a href="mailto:ibsafufa2010@gmail.com"><Mail size={18} /> ibsafufa2010@gmail.com</a>
              <a href="#contact"><MessageCircle size={18} /> Replies within one business day</a>
              <a href="https://t.me/ibsa-fufa" target="_blank" rel="noreferrer"><Send size={18} /> t.me/ibsa-fufa</a>
              <a href="https://www.tiktok.com/@ibsa-fufa-fayisa" target="_blank" rel="noreferrer"><Music2 size={18} /> @ibsa-fufa-fayisa on TikTok</a>
            </div>
          </div>
          <form className="inquiry-form" onSubmit={handleSubmit}>
            {submitted ? (
              <div className="form-success">
                <div className="success-icon"><Check size={25} /></div>
                <h3>Thanks — I’ve got it.</h3>
                <p>Your request is ready to review. I’ll be in touch with a clear next step.</p>
                <button className="button button-secondary" type="button" onClick={() => setSubmitted(false)}>Send another request</button>
              </div>
            ) : (
              <>
                <div className="form-heading"><span>Service inquiry</span><small>Fields marked * are required</small></div>
                <label>Name *<input name="name" required placeholder="Your name" /></label>
                <label>Email *<input name="email" required type="email" placeholder="you@example.com" /></label>
                <label>Phone number<input name="phone" type="tel" placeholder="Your phone number" /></label>
                <label>What needs attention? *
                  <select name="device" required defaultValue="">
                    <option value="" disabled>Select a device</option>
                    <option>Computer</option><option>Mobile phone</option><option>Laptop</option><option>Not sure yet</option>
                  </select>
                </label>
                <label>Tell me a little more *<textarea name="issue" required rows={4} placeholder="What is happening, and what would you like help with?" /></label>
                {submitError && <p role="alert" className="form-error">{submitError}</p>}
                <button className="button button-primary form-submit" type="submit" disabled={submitting}>{submitting ? "Sending…" : "Request help"} <ArrowUpRight size={17} /></button>
              </>
            )}
          </form>
        </section>
      </main>

      <footer className="site-footer">
        <div className="footer-brand"><span className="brand-mark"><Wrench size={17} /></span><strong>Ibsa-Fufa Device Care</strong></div>
        <p>Clear support for the devices that keep life moving.</p>
        <div className="footer-links">
          <a href="mailto:ibsafufa2010@gmail.com">Email</a>
          <a href="https://t.me/ibsa-fufa" target="_blank" rel="noreferrer">Telegram</a>
          <a href="https://www.tiktok.com/@ibsa-fufa-fayisa" target="_blank" rel="noreferrer">TikTok</a>
          <a href="#top">Back to top <ArrowUpRight size={15} /></a>
        </div>
      </footer>
    </div>
  );
}
